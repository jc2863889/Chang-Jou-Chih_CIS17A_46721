/* 
 * File:   main.cpp
 * Author: Jou-Chih Chang
 * Created on June 26, 2020, 4:43 PM
 * Purpose:  Predict the size of a population of organisms
 */

//System Libraries
#include <iostream>  //I/O Library
#include <iomanip>  //Format Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Set the random number seed here
    
    //Declare all variables for this function
    int start;
    double PopIncr;
    int days;
    int day;
    
    //Initialize all known variables
    start = 0;
    PopIncr = 0;
    days = 0;
    day = 0;
    
    //Input the starting number of organisms, their average daily population increase (as a percentage), 
    //and the number of days they will multiply
    cout << "Please enter the starting number of organisms(>=2): ";
    cin >> start;
    while(start < 2)
    {
        cout << "The starting number of organisms can not less than 2." << endl;
        cout << "Please enter the starting number of organisms(>=2): ";
        cin >> start;
    }
    cout << "Please enter the average daily population increase (as a percentage): ";
    cin >> PopIncr;
    while(PopIncr < 0)
    {
        cout << "The average daily population increase can not be a negative number." << endl;
        cout << "Please enter the average daily population increase (as a percentage): ";
        cin >> PopIncr;
    }
    cout << "Please enter the number of days(>=1): ";
    cin >> days;
    while(days < 1)
    {
        cout << "The number of days can not less than 1." << endl;
        cout << "Please enter the number of days(>=1): ";
        cin >> days;
    }
    
    //Process Inputs to Outputs -> Mapping Process
    //Maps known values to the unknown objectives
    //Display the Inputs/Outputs
    cout << setw(5) << "Day" << setw(30) << "Organisms Count" << endl;
    while(day <= days)
    {
        cout << setw(5) << day << setw(30) << start << endl;
        start = start * (1 + PopIncr / 100);
        day++;
    }

    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}