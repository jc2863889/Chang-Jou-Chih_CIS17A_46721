/* 
 * File:   main.cpp
 * Author: Jou-Chih Chang
 * Created on June 26, 2020, 12:30 PM
 * Purpose:  Convert U.S. dollar amounts to Japanese yen and to euros.
 */

//System Libraries
#include <iostream>  //I/O Library
#include <iomanip>  //Format Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants
const double YEN_PER_DOLLAR = 98.93; // One U.S. dollar equals to 98.93 Japanese yen
const double EUROS_PER_DOLLAR = 0.74; // One U.S. dollar equals to 0.74 euros

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Set the random number seed here
    
    //Declare all variables for this function
    double dollars;
    double yen;
    double euros;
    
    //Initialize all known variables
    dollars = 0;
    yen = 0;
    euros = 0;
    
    //Input the U.S. dollar amounts
    cout << "Please enter the U.S. dollar amounts: ";
    cin >> dollars;
    
    //Process Inputs to Outputs -> Mapping Process
    //Maps known values to the unknown objectives
    yen = dollars * YEN_PER_DOLLAR;
    euros = dollars * EUROS_PER_DOLLAR;
    
    //Display the Inputs/Outputs
    cout << setprecision(2) << fixed << showpoint; // Set the desired output formatting for numbers
    cout << "The U.S. dollar amounts " << dollars << " equals to the Japanese yen " << yen << " and the euros " << euros << "." << endl;

    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}