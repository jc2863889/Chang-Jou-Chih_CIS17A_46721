/* 
 * File:   main.cpp
 * Author: Jou-Chih Chang
 * Created on June 26, 2020, 8:28 PM
 * Purpose:  Write a function to convert a temperature from Fahrenheit to Celsius, Display a table of the Fahrenheit temperatures 0 through 20 and their Celsius equivalents
 */

//System Libraries
#include <iostream>  //I/O Library
#include <iomanip>  //Format Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes
double celsius(double); //Convert a temperature from Fahrenheit to Celsius

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Set the random number seed here
    
    //Declare all variables for this function
    double F;
    
    //Initialize all known variables
    F = 20;
    
    //Process Inputs to Outputs -> Mapping Process
    //Maps known values to the unknown objectives
    //Display the Inputs/Outputs
    cout << left << setw(15) << "Fahrenheit" << setw(10) << "Celsius" << endl;
    for(double i = 0; i <= F; i++)
    {
        cout << setprecision(2) << fixed << showpoint; // Set the desired output formatting for temperatures 
        cout << setw(15) << i << setw(10) << celsius(i) << endl;
    }

    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}

double celsius(double num)
{
    double C;
    C = 5 * (num - 32) / 9;
    return C;
}