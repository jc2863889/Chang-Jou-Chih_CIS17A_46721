/* 
 * File:   main.cpp
 * Author: Jou-Chih Chang
 * Created on June 26, 2020, 11:14 AM
 * Purpose:  Converts Celsius temperatures to Fahrenheit temperatures
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Set the random number seed here
    
    //Declare all variables for this function
    double F;
    double C;
    
    //Initialize all known variables
    F = 0;
    C = 0;
    
    //Input the Celsius temperatures
    cout << "Please enter the Celsius temperatures: ";
    cin >> C;
    
    //Process Inputs to Outputs -> Mapping Process
    //Maps known values to the unknown objectives
    F = 9 * C / 5 + 32;
    
    //Display the Inputs/Outputs
    cout << "The Celsius temperatures " << C << " equals to the Fahrenheit temperatures " << F << "." << endl;

    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}