/* 
 * File:   main.cpp
 * Author: Jou-Chih Chang
 * Created on June 28, 2020, 6:14 PM
 * Purpose:  Modify the binarySearch function so it searches an array of strings instead of an array of ints
 */

//System Libraries
#include <iostream>  //I/O Library
#include <string>
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants
const int NUM_NAMES = 20;

//Function Prototypes
void bubbleSort(string[], int);
int binarySearch(string[], int, string);

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Set the random number seed here
    
    //Declare all variables for this function
    string search;
    int results;
    
    //Input the name you want to search for
    cout << "Please enter the name you want to search for: ";
    getline(cin,search);
    
    //Initialize all known variables
     string names[NUM_NAMES] = {"Collins, Bill", "Smith, Bart", "Allen, Jim",
                                "Griffin, Jim", "Stamey, Marty", "Rose, Geri",
                                "Taylor, Terri", "Johnson, Jill", "Allison, Jeff",
                                "Looney, Joe", "Wolfe, Bill", "James, Jean",
                                "Weaver, Jim", "Pore, Bob", "Rutherford, Greg",
                                "Javens, Renee", "Harrison, Rose", "Setzer, Cathy",
                                "Pike, Gordon", "Holland, Beth" };
     
    //Process Inputs to Outputs -> Mapping Process
    //Maps known values to the unknown objectives
    bubbleSort(names, NUM_NAMES);
    results = binarySearch(names, NUM_NAMES, search);
    
    //Display the Inputs/Outputs
    if (results == -1)
    {
        cout << "That name does not exist in the array." << endl;
    }
    else
    {
        cout << "Name " << search << " was found in element " << results << " of the array." << endl;
    }
    
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}

void bubbleSort(string array[], int size)
{
    int maxElement;
    int index;
    
    for (maxElement = size - 1; maxElement > 0; maxElement--)
    {
        for (index = 0; index < maxElement; index++)
        {
            if (array[index] > array[index + 1])
            {
                swap(array[index], array[index + 1]);
            }
        }
    }
}

int binarySearch(string array[], int numElems, string value)
{
    int first = 0,            // First array element
        last = numElems - 1,  // Last array element
        middle,               // Midpoint of search
        position = -1;        // Position of search value
    bool found = false;       // Flag
    while(!found && first <= last)
    {
        middle = (first + last) / 2;  // Calculate midpoint
        if (array[middle] == value)  // If value is found at mid
        {
            found = true;
            position = middle;
        }
        else if (array[middle] > value)  // If value is in lower half
        {
            last = middle - 1;
        }
        else
        {
            first = middle + 1;  // If value is in upper half
        }   
    }
    return position;
}