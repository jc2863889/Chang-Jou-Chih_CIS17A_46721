/* 
 * File:   main.cpp
 * Author: Jou-Chih Chang
 * Created on June 26, 2020, 2:30 PM
 * Purpose:  Display the number of days in the month 
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Set the random number seed here
    
    //Declare all variables for this function
    int month;
    int year;
    
    //Initialize all known variables
    month = 0;
    year = 0;
    
    //Input a month and a year
    cout << "Enter a month (1-12): ";
    cin >> month;
    cout << "Enter a year: ";
    cin >> year;
    if(year < 0)
    {
        cout << "Error. Invalid year entered." << endl;
        return 0;
    }
    
    //Process Inputs to Outputs -> Mapping Process
    //Maps known values to the unknown objectives
    //Display the Inputs/Outputs
    switch(month)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12: cout << "31 days" << endl;
                 break;
        case 4:
        case 6:
        case 9:
        case 11: cout << "30 days" << endl;
                 break;
        case 2: if(year % 100 == 0 && year % 400 == 0)
                {
                    cout << "29 days" << endl;
                }
                else if(year % 100 != 0 && year % 4 == 0)
                {
                    cout << "29 days" << endl;
                }
                else 
                {
                    cout << "28 days" << endl;
                }
                break;
        default: cout << "That is an invalid month." << endl;
    }

    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}